drop database if exists example;
create database if not exists example character set = utf8mb4;
use example;

drop table if exists users;
create table users(
	id int unsigned not null auto_increment unique,
	name varchar(50) -- username
	
);